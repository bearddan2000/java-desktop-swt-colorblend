package colorblend;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class App  extends JFrame {
	private JLabel label;
    HashMap<String, Color> blendMap = new HashMap<String, Color>();
    
	public App() {
		setTitle("JButton Text Change");        // set the rows and cols of the grid, as well the distances between them
		setLayout(new BorderLayout());
		JPanel panel = new JPanel();
        GridLayout grid = new GridLayout(5, 3, 10, 10);
        // what layout we want to use for our frame
        panel.setLayout(grid);
		
        String[] items = new String[] {"red", "green", "pink", "yellow", "orange", "gray", 
        		"lightGray", "darkGray", "cyan", "blue", "black", "white"};
		for(String x:items){
			JCheckBox checkBox = new JCheckBox(x);
			checkBox.addItemListener(new ItemListener() {

			    public void itemStateChanged(ItemEvent e) {
			    	JCheckBox c = (JCheckBox)e.getSource();
			        String text = c.getText();
			        Color change = null;
			        Color original = label.getBackground();
			        Color next = App.fromName(text);
			        
			        if(c.isSelected()) 
			        	blendMap.put(text, next);
			        else
			        	blendMap.remove(text);

		        	change = App.add(blendMap);
			        label.setBackground(change);
			    }
			});
			panel.add(checkBox);
		}
		label = new JLabel("Hello");
		label.setOpaque(true);
		label.setBackground(Color.decode("#ffdead"));
		label.setSize(200, 75);
		add(label, BorderLayout.NORTH);
		this.blendMap.put("original", Color.decode("#ffdead"));
		add(panel, BorderLayout.CENTER);
		setSize(300, 250);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setVisible(true);
	}
	private static Color fromName(String name){
		Color color;
		try {
		    Field field = Class.forName("java.awt.Color").getField(name);
		    color = (Color)field.get(null);
		} catch (Exception e) {
		    color = null; // Not defined
		}
		return color;
	}
	private static Color add(HashMap<String, Color> blendMap) {
	    float ratio = 1f / ((float) blendMap.size());
	    int r = 0, g = 0, b = 0, a = 0;
	    for (Map.Entry<String, Color> entry : blendMap.entrySet()) {
	    	Color color = entry.getValue();
	        r += color.getRed() * ratio;
	        g += color.getGreen() * ratio;
	        b += color.getBlue() * ratio;
	        a += color.getAlpha() * ratio;
	    }
	    return new Color(r, g, b, a);
	}
	public static void main(String[] args) {
		new App();
	}

}

